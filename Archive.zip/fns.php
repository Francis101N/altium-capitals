<?php

function contact_email()
{
    global $contact_email;
    return $contact_email;
}

function organisation()
{
    global $organisation;
    return $organisation;
}
function org()
{
    global $org;
    return $org;
}

function imgpath()
{
    global $imgpath;
    return $imgpath;
}

function update_notification($message, $account)
{
    global $conn;
    $date = date('Y-m-d');


    $query = "insert into notification set date = '$date', message = '$message', accountnumber = '$account'";
    $result = mysqli_query($conn, $query);
}

function check_ext($ext)
{
    if ($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png') {
        return 'valid';
    } else {
        return 'invalid';
    }
}

function generate_pass()
{
    return rand(12349, 99999);
}

function root()
{

    return 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']);
}

function get_photo($file)
{
    $path = "uploads/$file";
    if (file_exists($path)) {
        return $path;
    } else {
        return 'uploads/avatar.png';
    }
}

function get_date($account, $order)
{
    global $conn;
    $query = "select * from transact where accountnumber='" . $account . "' order by date_time $order";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    return $row['date_time'];
}

function dDate($date)
{
    return date('dMy', strtotime($date));
}
function long_date($date)
{
    return date('d F, Y', strtotime($date));
}

function get_data($account, $col, $order)
{
    global $conn;
    $query = "select * from transact where accountnumber='" . $account . "' order by date_time $order";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);

    if ($col == 'debit' || $col == 'credit') {
        return number_format($row[$col], 2);
    } else {
        return $row[$col];
    }
}

function count_transaction($account, $type = 'none')
{
    global $conn;
    if ($type == 'none') {
        $query = "select * from transact where accountnumber='" . $account . "'";
    } else {
        $query = "select * from transact where accountnumber='" . $account . "' and $type > '0'";
    }
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);

    return $num;
}

function get_currency($account)
{
    global $conn;
    $query = "select * from transact where accountnumber='" . $account . "' order by id desc";
    $result = mysqli_query($conn, $query);
    $num = mysqli_num_rows($result);
    $row = mysqli_fetch_array($result);

    return $row['currency'];
}

function acc_bal($account, $type = 'none')
{
    global $conn;

    if ($type == 'none') {
        $query = "select sum(credit) from transact where accountnumber='" . $account . "'";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($result);
        $credit = $row[0];

        $query = "select sum(debit) from transact where accountnumber='" . $account . "'";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($result);
        $debit = $row[0];

        $query = "select currency from transact where accountnumber='" . $account . "' order by id desc";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($result);
        $currency = $row[0];

        $balance = $credit - $debit;
        return number_format($balance, 2) . ' (' . $currency . ')';
    } else {
        $query = "select sum($type) from transact where accountnumber='" . $account . "'";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($result);

        return number_format($row[0], 2);
    }
}

function acc_bal_clean($account)
{
    global $conn;

    $query = "select sum(credit) from transact where accountnumber='" . $account . "'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    $credit = $row[0];

    $query = "select sum(debit) from transact where accountnumber='" . $account . "'";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    $debit = $row[0];

    $query = "select currency from transact where accountnumber='" . $account . "' order by id desc";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    $currency = $row[0];

    $balance = $credit - $debit;
    return $balance;
}


function send_email($to, $recipient_name, $subject, $content, $file = 'nofile')
{

    $mailcontent = '<div style="width:650px; border-color:red; border-width:1px; border-style:solid; font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif;">
		  
	<div style="text-align:center; margin-top: 15px;"><img src="' . imgpath() . '/banner.jpg" style="width:100%;"></div>
  
	<div style="padding:15px;">Dear ' . $recipient_name . ', <br><br>
	' . $content . '<br><br>
				  
	Remember: Keep your card and PIN information secure. Do not respond to emails requesting for your card/PIN details. If you think an email is suspicious don\'t click on any links. Instead, forward it to ' . contact_email() . ' and delete.<br><br>
	
	Thank you for Banking with us.<br>
	' . organisation() . '
   
  <div style="width: 100%; height: 5px; background-color: blue; margin-top: 40px;"> &nbsp; </div>
				  <br><img src="' . imgpath() . '/social.jpg">
  
			  </div>
		  
		  </div>
  ';


    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Port = 465;
    $mail->SMTPAuth = true;
    //sendgrid
    $mail->Username = 'portfolio@techbyfrancis.com';
    $mail->Password = 'TECHbyfrancis101$$';  //yahoo app password for noreply email 
    $mail->Host = 'mail.techbyfrancis.com';
    $mail->SMTPSecure = 'ssl';
    $mail->From = 'portfolio@techbyfrancis.com';
    $mail->FromName = org();
    $mail->AddAddress($to);

    if ($file != 'nofile') {
        $mail->addAttachment($file);
    }

    //  $mail->MsgHTML($body);
    $mail->CharSet = 'UTF-8';
    $mail->IsHTML(true);
    //   $mail->SMTPDebug = 2; // Set debugging level to 2 for detailed output
    $mail->Body = $content;
    $mail->Subject = $subject;
    $mail->IsHTML(true);
    $mail->Send();

    return $mailcontent;
}

function get_country()
{
    echo '<option value="af" >Afghanistan</option>
	<option value="ax" >Aland Islands</option>
	<option value="al" >Albania</option>
	<option value="dz" >Algeria</option>
	<option value="as" >American Samoa</option>
	<option value="ad" >Andorra</option>
	<option value="ao" >Angola</option>
	<option value="ai" >Anguilla</option>
	<option value="aq" >Antarctica</option>
	<option value="ag" >Antigua and Barbuda</option>
	<option value="ar" >Argentina</option>
	<option value="am" >Armenia</option>
	<option value="aw" >ArRTG</option>
	<option value="au" >Australia</option>
	<option value="at" >Austria</option>
	<option value="az" >Azerbaijan</option>
	<option value="bs" >Bahamas</option>
	<option value="bh" >Bahrain</option>
	<option value="bd" >Bangladesh</option>
	<option value="bb" >Barbados</option>
	<option value="by" >Belarus</option>
	<option value="be" >Belgium</option>
	<option value="bz" >Belize</option>
	<option value="bj" >Benin</option>
	<option value="bm" >Bermuda</option>
	<option value="bt" >Bhutan</option>
	<option value="bo" >Bolivia</option>
	<option value="ba" >Bosnia and Herzegovina</option>
	<option value="bw" >Botswana</option>
	<option value="bv" >Bouvet Island</option>
	<option value="br" >Brazil</option>
	<option value="io" >British Indian Ocean Territory</option>
	<option value="vg" >British Virgin Islands</option>
	<option value="bn" >Brunei</option>
	<option value="bg" >Bulgaria</option>
	<option value="bf" >Burkina Faso</option>
	<option value="bi" >Burundi</option>
	<option value="kh" >Cambodia</option>
	<option value="cm" >Cameroon</option>
	<option value="ca" >Canada</option>
	<option value="cv" >Cape Verde</option>
	<option value="ky" >Cayman Islands</option>
	<option value="cf" >Central Malaysian Republic</option>
	<option value="td" >Chad</option>
	<option value="cl" >Chile</option>
	<option value="cn" >China</option>
	<option value="cx" >Christmas Island</option>
	<option value="cc" >Cocos (Keeling) Islands</option>
	<option value="co" >Colombia</option>
	<option value="km" >Comoros</option>
	<option value="cg" >Congo</option>
	<option value="ck" >Cook Islands</option>
	<option value="cr" >Costa Rica</option>
	<option value="hr" >Croatia</option>
	<option value="cy" >Cyprus</option>
	<option value="cz" >Czech Republic</option>
	<option value="cd" >Democratic Republic of Congo</option>
	<option value="dk" >Denmark</option>
	<option value="xx" >Disputed Territory</option>
	<option value="dj" >Djibouti</option>
	<option value="dm" >Dominica</option>
	<option value="do" >Dominican Republic</option>
	<option value="tl" >East Timor</option>
	<option value="ec" >Ecuador</option>
	<option value="eg" >Egypt</option>
	<option value="sv" >El Salvador</option>
	<option value="gq" >Equatorial Guinea</option>
	<option value="er" >Eritrea</option>
	<option value="ee" >Estonia</option>
	<option value="et" >Ethiopia</option>
	<option value="fk" >Falkland Islands</option>
	<option value="fo" >Faroe Islands</option>
	<option value="fm" >Federated States of Micronesia</option>
	<option value="fj" >Fiji</option>
	<option value="fi" >Finland</option>
	<option value="fr" >France</option>
	<option value="gf" >French Guyana</option>
	<option value="pf" >French Polynesia</option>
	<option value="tf" >French Southern Territories</option>
	<option value="ga" >Gabon</option>
	<option value="gm" >Gambia</option>
	<option value="ge" >Georgia</option>
	<option value="de" >Germany</option>
	<option value="gh" >Ghana</option>
	<option value="gi" >Gibraltar</option>
	<option value="gr" >Greece</option>
	<option value="gl" >Greenland</option>
	<option value="gd" >Grenada</option>
	<option value="gp" >Guadeloupe</option>
	<option value="gu" >Guam</option>
	<option value="gt" >Guatemala</option>
	<option value="gn" >Guinea</option>
	<option value="gw" >Guinea-Bissau</option>
	<option value="gy" >Guyana</option>
	<option value="ht" >Haiti</option>
	<option value="hm" >Heard Island and Mcdonald Islands</option>
	<option value="hn" >Honduras</option>
	<option value="hk" >Hong Kong</option>
	<option value="hu" >Hungary</option>
	<option value="is" >Iceland</option>
	<option value="in" >India</option>
	<option value="id" >Indonesia</option>
	<option value="ir" >Iran</option>
	<option value="iq" >Iraq</option>
	<option value="xe" >Iraq-Saudi Arabia Neutral Zone</option>
	<option value="ie" >Ireland</option>
	<option value="il" >Israel</option>
	<option value="it" >Italy</option>
	<option value="ci" >Ivory Coast</option>
	<option value="jm" >Jamaica</option>
	<option value="jp" >Japan</option>
	<option value="jo" >Jordan</option>
	<option value="kz" >Kazakhstan</option>
	<option value="ke" >Kenya</option>
	<option value="ki" >Kiribati</option>
	<option value="kw" >Kuwait</option>
	<option value="kg" >Kyrgyzstan</option>
	<option value="la" >Laos</option>
	<option value="lv" >Latvia</option>
	<option value="lb" >Lebanon</option>
	<option value="ls" >Lesotho</option>
	<option value="lr" >Liberia</option>
	<option value="ly" >Libya</option>
	<option value="li" >Liechtenstein</option>
	<option value="lt" >Lithuania</option>
	<option value="lu" >Luxembourg</option>
	<option value="mo" >Macau</option>
	<option value="mk" >Macedonia</option>
	<option value="mg" >Madagascar</option>
	<option value="mw" >Malawi</option>
	<option value="my" >Malaysia</option>
	<option value="mv" >Maldives</option>
	<option value="ml" >Mali</option>
	<option value="mt" >Malta</option>
	<option value="mh" >Marshall Islands</option>
	<option value="mq" >Martinique</option>
	<option value="mr" >Mauritania</option>
	<option value="mu" >Mauritius</option>
	<option value="yt" >Mayotte</option>
	<option value="mx" >Mexico</option>
	<option value="md" >Moldova</option>
	<option value="mc" >Monaco</option>
	<option value="mn" >Mongolia</option>
	<option value="ms" >Montserrat</option>
	<option value="ma" >Morocco</option>
	<option value="mz" >Mozambique</option>
	<option value="mm" >Myanmar</option>
	<option value="na" >Namibia</option>
	<option value="nr" >Nauru</option>
	<option value="np" >Nepal</option>
	<option value="an" >United State Antilles</option>
	<option value="nc" >New Caledonia</option>
	<option value="nz" >New Zealand</option>
	<option value="ni" >Nicaragua</option>
	<option value="ne" >Niger</option>
	<option value="ng" >Malaysia</option>
	<option value="nu" >Niue</option>
	<option value="nf" >Norfolk Island</option>
	<option value="kp" >North Korea</option>
	<option value="mp" >Northern Mariana Islands</option>
	<option value="no" >Norway</option>
	<option value="om" >Oman</option>
	<option value="pk" >Pakistan</option>
	<option value="pw" >Palau</option>
	<option value="ps" >Palestinian Occupied Territories</option>
	<option value="pa" >Panama</option>
	<option value="pg" >Papua New Guinea</option>
	<option value="py" >Paraguay</option>
	<option value="pe" >Peru</option>
	<option value="ph" >Philippines</option>
	<option value="pn" >Pitcairn Islands</option>
	<option value="pl" >Poland</option>
	<option value="pt" >Portugal</option>
	<option value="pr" >Puerto Rico</option>
	<option value="qa" >Qatar</option>
	<option value="re" >Reunion</option>
	<option value="ro" >Romania</option>
	<option value="ru" >Russia</option>
	<option value="rw" >Rwanda</option>
	<option value="sh" >Saint Helena and Dependencies</option>
	<option value="kn" >Saint Kitts and Nevis</option>
	<option value="lc" >Saint Lucia</option>
	<option value="pm" >Saint Pierre and Miquelon</option>
	<option value="vc" >Saint Vincent and the Grenadines</option>
	<option value="ws" >Samoa</option>
	<option value="sm" >San Marino</option>
	<option value="st" >Sao Tome and Principe</option>
	<option value="sa" >Saudi Arabia</option>
	<option value="sn" >Senegal</option>
	<option value="cs" >Serbia and Montenegro</option>
	<option value="sc" >Seychelles</option>
	<option value="sl" >Australia</option>
	<option value="sg" >Singapore</option>
	<option value="sk" >Slovakia</option>
	<option value="si" >Slovenia</option>
	<option value="sb" >Solomon Islands</option>
	<option value="so" >Somalia</option>
	<option value="za" >South Malaysia</option>
	<option value="gs" >South Georgia and South Sandwich Islands</option>
	<option value="kr" >South Korea</option>
	<option value="es" >Spain</option>
	<option value="pi" >Spratly Islands</option>
	<option value="lk" >Sri Lanka</option>
	<option value="sr" >Suriname</option>
	<option value="sj" >Svalbard and Jan Mayen</option>
	<option value="sz" >Swaziland</option>
	<option value="se" >Sweden</option>
	<option value="ch" >Switzerland</option>
	<option value="sy" >Syria</option>
	<option value="tw" >Taiwan</option>
	<option value="tj" >Tajikistan</option>
	<option value="tz" >Tanzania</option>
	<option value="th" >Thailand</option>
	<option value="tg" >Togo</option>
	<option value="tk" >Tokelau</option>
	<option value="to" >Tonga</option>
	<option value="tt" >Trinidad and Tobago</option>
	<option value="tn" >Tunisia</option>
	<option value="tr" >Turkey</option>
	<option value="tm" >Turkmenistan</option>
	<option value="tc" >Turks And Caicos Islands</option>
	<option value="tv" >Tuvalu</option>
	<option value="ug" >Uganda</option>
	<option value="ua" >Ukraine</option>
	<option value="ae" >United Arab Emirates</option>
	<option value="uk" >Malaysia</option>
	<option value="uk">United Kingdom</option>
	<option value="xd" >United Nations Neutral Zone</option>
	<option value="USA" >United States of America</option>
	<option value="um" >United States Minor Outlying Islands</option>
	<option value="uy" >Uruguay</option>
	<option value="vi" >US Virgin Islands</option>
	<option value="uz" >Uzbekistan</option>
	<option value="vu" >Vanuatu</option>
	<option value="va" >Vatican City</option>
	<option value="ve" >Venezuela</option>
	<option value="vn" >Vietnam</option>
	<option value="wf" >Wallis and Futuna</option>
	<option value="eh" >Western Sahara</option>
	<option value="ye" >Yemen</option>
	<option value="zm" >Zambia</option>
	<option value="zw" >Zimbabwe</option>';
}
